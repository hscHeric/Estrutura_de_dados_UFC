#include <iostream>
#include <string>
#include <vector>
using namespace std;

namespace ufc {
    // retorna o maior entre dois elementos
    template< typename T >
    T max(T x, T y) {
        if (x >= y) 
            return x;
        else
            return y;
    }
    // Imprime um vetor na tela
    template< typename T >
    void print(vector<T>& vec) {
        for(T elemento : vec) {
            cout << elemento << " ";
        }
        cout << endl;
    }

}

int main() {
    cout << ufc::max<short>(4, 7) << endl; // explicitamente um short
    cout << ufc::max(4.5, 4.4) << endl; // implicitamente um double
    cout << ufc::max<std::string>("aba", "ana") << endl; // explicitamente um std::string

    vector<int> vet {1,2,3,4,5,6,7};
    ufc::print(vet);
}