#include <iostream>
#include "List.h"
using namespace std;

int main() {
    List<float> list;
}