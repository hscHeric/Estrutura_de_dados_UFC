#include <iostream>
#include "Vector.h"
using namespace std;

template< typename T>
void print(const Vector<T>& lst) {
	cout << "capacity: " << lst.capacity() << endl;
	cout << "size: " << lst.size() << endl;
	for(int i = 0; i < lst.size(); i++) {
		cout << lst.at(i) << " ";
	}
	cout << endl;
}

int main() {
	Vector<double> lista;

	for(int i = 1; i < 10; ++i) 
		lista.push_back(i);

	print(lista);
}