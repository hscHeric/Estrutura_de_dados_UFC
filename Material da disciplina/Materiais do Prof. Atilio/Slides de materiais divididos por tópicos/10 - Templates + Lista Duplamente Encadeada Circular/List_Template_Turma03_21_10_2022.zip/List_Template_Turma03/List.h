/**
 * @file List.h
 * @author Atilio Luiz
 * @brief Lista duplamente encadeada circular com node sentinela
 * @version 0.1
 * @date 2022-10-21
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#ifndef LIST_H
#define LIST_H
#include <stdexcept> // usado pela a classe std::range_error
#include "Node.h"

template< typename T >
class List {
private:
    Node<T> *m_head {nullptr}; // ponteiro para um Node<T>
    int m_size {0}; // numero de elementos na lista

public:
    // definicao da classe iterator
    class iterator {
    private:
        Node<T> *ptr;
    public:
        iterator(Node<T> *pointer) {
            ptr = pointer;
        }
        bool operator!=(const iterator& it) {
            return ptr != it.ptr;
        }
        T& operator*() {
            return ptr->value;
        }
        iterator& operator++() {
            ptr = ptr->next;
            return *this;
        }
    };

    // Funcoes-membro que retornam iteradores para o inicio da lista e depois-do-fim da lista
    iterator begin() {
        return iterator(m_head->next);
    }
    iterator end() {
        return iterator(m_head);
    }


    // Construtor: cria lista vazia, com 
    // m_head apontando para um node sentinela
    List() {
        m_head = new Node<T>(0, nullptr, nullptr);
        m_head->next = m_head;
        m_head->prev = m_head;
    }
    // insere um elemento no final da lista
    void push_back(const T& val) { // O(1)
        Node<T> *aux = new Node<T>(val, m_head->prev, m_head);
        (aux->prev)->next = aux;
        m_head->prev = aux;
        m_size++;    
    }
    // Operador de indexacao
    T& operator[](int index) {
        if(index < 0 || index >= m_size) {
            throw std::range_error("indice invalido");
        }
        Node<T> *aux = m_head->next;
        for(int i = 0; i < index; ++i) {
            aux = aux->next;
        }
        return aux->value;
    }
    // Operador de indexacao: versao const
    const T& operator[](int index) const {
        if(index < 0 || index >= m_size) {
            throw std::range_error("indice invalido");
        }
        Node<T> *aux = m_head->next;
        for(int i = 0; i < index; ++i) {
            aux = aux->next;
        }
        return aux->value;
    }
    // retorna o numero de elementos da lista
    int size() const {
        return m_size;
    }
    // retorna true se e somente se lista estiver vazia
    bool empty() const {
        return m_size == 0;
    }
    // Remove o ultimo elemento da lista
    void pop_back() { // O(1)
        if(!empty()) {
            Node<T> *aux = m_head->prev;
            m_head->prev = aux->prev;
            (aux->prev)->next = m_head;
            delete aux;
            m_size--;
        }
    }
    // deixa a lista vazia, liberando memoria
    void clear() {
        Node<T> *aux = m_head->prev;
        while(aux != m_head) {
            Node<T> *temp = aux;
            aux = temp->prev;
            delete temp;
        }
        m_head->next = m_head->prev = m_head;
        m_size = 0;
    }
    // Destrutor
    ~List() {
        clear();
        delete m_head;
    }
};

#endif