#include <iostream>
#include "List.h"
using namespace std;

int main() {
    List<int> list; // Cria lista de int vazia

    for(int i = 1; i <= 20; i++) 
        list.push_back(i);

    // Imprime lista na tela
    for(int i = 0; i < list.size(); i++) // O(n^2)
        cout << list[i] << " ";
    cout << endl;

    // Imprime lista na tela usando o iterador que programamos na aula
    for(List<int>::iterator it = list.begin(); it != list.end(); ++it) { // O(n)
        cout << *it << " ";
    }
    cout << endl;
}

